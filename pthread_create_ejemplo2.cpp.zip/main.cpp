/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>

#define NUMERO_DE_HILOS 5  // Cantidad de hilos a crear

// Función que ejecutará cada hilo
void *imprimir_hola_mundo(void *arg) {
    int id = *(int *)arg;  // Recuperamos el ID del hilo
    printf("Hola mundo. Soy el hilo %d\n", id);
    return NULL;           // El hilo termina
}

int main() {
    pthread_t hilos[NUMERO_DE_HILOS];  // Arreglo de identificadores de hilos
    int ids[NUMERO_DE_HILOS];          // Arreglo para pasar los IDs
    int i;

    // Crear hilos
    for (i = 0; i < NUMERO_DE_HILOS; i++) {
        ids[i] = i;  // Asignamos un número a cada hilo
        printf("Main: creando el hilo %d\n", i);
        if (pthread_create(&hilos[i], NULL, imprimir_hola_mundo, &ids[i]) != 0) {
            perror("Error al crear el hilo");
            exit(1);
        }
    }

    // Esperar a que todos los hilos terminen
    for (i = 0; i < NUMERO_DE_HILOS; i++) {
        pthread_join(hilos[i], NULL);
    }

    printf("Main: todos los hilos han terminado.\n");
    return 0;
}