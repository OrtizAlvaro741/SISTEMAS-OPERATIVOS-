/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <cstdio>
#include <cstdlib>
#include <pthread.h>
#include <semaphore.h>
#include <unistd.h>
#include <time.h>

#define N 5

int buffer[N];
int count = 0;
int in = 0, out = 0;

sem_t empty;
sem_t full;
pthread_mutex_t mutex;

void* productor(void*){
    srand(time(NULL));
    while (1){
        int item = rand() % 100;

        sem_wait(&empty);
        pthread_mutex_lock(&mutex);

        buffer[in] = item;
        in = (in + 1) % N;
        count++;  // <-- aquí estaba el error: antes decía cout++

        printf("Productor produjo: %d | Elementos en buffer: %d\n", item, count);

        pthread_mutex_unlock(&mutex);
        sem_post(&full);

        sleep(1);
    }
    return NULL;
}

void* consumidor(void*){
    while (1){
        sem_wait(&full);
        pthread_mutex_lock(&mutex);

        int item = buffer[out];
        out = (out + 1) % N;
        count--;

        printf("Consumidor consumió: %d | Elementos en buffer: %d\n", item, count);

        pthread_mutex_unlock(&mutex);
        sem_post(&empty);

        sleep(2);
    }
    return NULL;
}

int main(){
    pthread_t prod, cons;

    sem_init(&empty, 0, N);
    sem_init(&full, 0, 0);
    pthread_mutex_init(&mutex, NULL);

    pthread_create(&prod, NULL, productor, NULL);
    pthread_create(&cons, NULL, consumidor, NULL);

    pthread_join(prod, NULL);   // <-- sin &
    pthread_join(cons, NULL);   // <-- sin &

    sem_destroy(&empty);
    sem_destroy(&full);
    pthread_mutex_destroy(&mutex);

    return 0;
}
