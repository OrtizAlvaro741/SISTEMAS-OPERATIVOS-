/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/
#include <pthread.h>
#include <stdio.h>
#include <iostream>

using namespace std;

void* imprimir(void*arg){
    printf ("hola desde el hilo\n");
    return NULL;
}


int main()
{  pthread_t hilo;
   pthread_create (&hilo, NULL, imprimir, NULL);
   pthread_join (hilo, NULL);

    return 0;
}